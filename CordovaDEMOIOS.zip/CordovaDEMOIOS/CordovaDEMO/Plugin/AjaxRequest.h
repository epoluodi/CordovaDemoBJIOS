//
//  AjaxRequest.h
//  CordovaDEMO
//
//  Created by 杨晓光 on 2016/12/12.
//  Copyright © 2016年 杨晓光. All rights reserved.
//

#import "CDVPlugin.h"

@interface AjaxRequest : CDVPlugin

//转发POST
-(void)POST:(CDVInvokedUrlCommand *)command;


@end
