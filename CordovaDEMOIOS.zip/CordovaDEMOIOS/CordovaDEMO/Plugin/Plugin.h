//
//  Plugin.h
//  CordovaDEMO
//
//  Created by 杨晓光 on 2016/12/5.
//  Copyright © 2016年 杨晓光. All rights reserved.
//

#define CDV_NEWOPENWINDOWS @"NEWOPENWINDOWS"
#define CDV_SHOWSIGNVIEW @"SHOWSIGNVIEW"
