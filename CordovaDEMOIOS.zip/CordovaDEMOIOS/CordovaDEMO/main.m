//
//  main.m
//  CordovaDEMO
//
//  Created by 杨晓光 on 2016/12/1.
//  Copyright © 2016年 杨晓光. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
